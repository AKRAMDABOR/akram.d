<!-- khaled elshorafa 120190878 -->

<!DOCTYPE html>
<html>
<head>
  <title>enter data</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
      margin: 0;
      padding: 0;
    }

    h2 {
      color: #333;
      text-align: center;
      margin-top: 50px;
    }

    form {
      width: 300px;
      margin: 0 auto;
      background-color: #fff;
      border-radius: 5px;
      padding: 20px;
    }

    label {
      display: block;
      margin-bottom: 10px;
      color: #333;
      font-weight: bold;
    }

    input[type="text"],
    input[type="email"] {
      width: 100%;
      padding: 5px;
      margin-bottom: 10px;
      border-radius: 3px;
      border: 1px solid #ccc;
    }

    input[type="submit"] {
      padding: 10px 20px;
      background: #333;
      color: #fff;
      border: none;
      border-radius: 3px;
      cursor: pointer;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 10px;
      border-bottom: 1px solid #ccc;
      text-align: left;
    }

    th {
      background: #f5f5f5;
      font-weight: bold;
    }
  </style>
  <style>
  </style>
</head>
<body>
  <h2>enter data form</h2>
  <form action="d.php" method="POST">
    <label for="name">name :</label>
    <input type="text" name="name" id="name" required><br><br>

    <label for="email">email :</label>
    <input type="email" name="email" id="email" required><br><br>

    <input type="submit" value="إرسال">
  </form>
</body>
</html>
