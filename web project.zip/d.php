<!-- khaled elshorafa 120190878 -->


<!DOCTYPE html>
<html>
<head>
  <title>show data</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f5f5f5;
      margin: 0;
      padding: 0;
    }

    h2 {
      color: #333;
      text-align: center;
      margin-top: 50px;
    }

    table {
      width: 600px;
      margin: 0 auto;
      background-color: #fff;
      border-collapse: collapse;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    th, td {
      padding: 10px;
      border-bottom: 1px solid #ccc;
      text-align: left;
    }

    th {
      background: #f5f5f5;
      font-weight: bold;
    }
  </style>
  <style>
  </style>
</head>
<body>
  <?php
  $host = 'localhost';
  $username = 'root';
  $password = '572001';
  $dbname = 'users';

  $conn = new mysqli($host, $username, $password, $dbname);

  if ($conn->connect_error) {
    die("can't connect to database: " . $conn->connect_error);
  }

  $name = $_POST['name'];
  $email = $_POST['email'];

  $sql = "INSERT INTO users (name, email) VALUES ('$name', '$email')";

  if ($conn->query($sql) === TRUE) {
    echo "data added succesfully";
  } else {
    echo "error :" . $conn->error;
  }

  $selectQuery = "SELECT * FROM users";
  $result = $conn->query($selectQuery);

  if ($result->num_rows > 0) {
    echo "<table>
          <tr>
            <th>name</th>
            <th>email</th>
          </tr>";
    while ($row = $result->fetch_assoc()) {
      echo "<tr>
            <td>" . $row["name"] . "</td>
            <td>" . $row["email"] . "</td>
          </tr>";
    }
    echo "</table>";
  } else {
    echo "there is no avilable data";
  }

  $conn->close();
  ?>
</body>
</html>
